const Home = () => {
  return <h1>This is Home</h1>;
}

export default Home;